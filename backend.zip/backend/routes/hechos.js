const express = require('express');
const router = express.Router();
const db = require('../db');
const HechosService = require('../services/hecho.service');
const HechoDTO = require('../dto/hechos_historicos.dto');
const authenticateToken = require('../middlewares/auth.middleware');

/**
 * @swagger
 * components:
 *   securitySchemes:
 *     BearerAuth:
 *       type: http
 *       scheme: bearer
 *       bearerFormat: JWT
 *
 * tags:
 *   - name: Hechos
 *     description: Endpoints para gestionar hechos históricos
 */

/**
 * @swagger
 * /api/hechos:
 *   get:
 *     summary: Obtiene la lista de hechos históricos (requiere autenticación)
 *     tags: [Hechos]
 *     security:
 *       - BearerAuth: []
 *     responses:
 *       200:
 *         description: Lista de hechos obtenida con éxito
 *       401:
 *         description: Acceso no autorizado
 */
router.get('/', authenticateToken, async (req, res) => {
    try {
        const hechos = await HechosService.getAllHechos();
        const hechosDTOs = hechos.map(hecho => new HechoDTO(hecho));
        res.json(hechosDTOs);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

/**
 * @swagger
 * /api/hechos/linea-tiempo:
 *   get:
 *     summary: Devuelve todos los hechos históricos ordenados cronológicamente
 *     tags: [Hechos]
 *     responses:
 *       200:
 *         description: Lista ordenada por fecha
 *       500:
 *         description: Error interno
 */
router.get('/linea-tiempo', async (req, res) => {
    try {
        const hechos = await HechosService.getHechosOrdenadosPorFecha();
        const hechosDTO = hechos.map(h => new HechoDTO(h));
        res.json(hechosDTO);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

/**
 * @swagger
 * /api/hechos/seccion/{id_seccion}:
 *   get:
 *     summary: Obtiene los hechos por sección
 *     tags: [Hechos]
 *     parameters:
 *       - in: path
 *         name: id_seccion
 *         required: true
 *         schema:
 *           type: integer
 *     responses:
 *       200:
 *         description: Lista de hechos por sección
 *       404:
 *         description: No se encontraron hechos
 */
router.get('/seccion/:id_seccion', async (req, res) => {
    try {
        const id_seccion = parseInt(req.params.id_seccion);
        const hechos = await HechosService.getHechosPorSeccion(id_seccion);

        if (hechos.length === 0) {
            return res.status(404).json({ error: 'No se encontraron hechos para esta sección' });
        }

        const hechosDTO = hechos.map(h => new HechoDTO(h));
        res.json(hechosDTO);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

/**
 * @swagger
 * /api/hechos/etiqueta/{id_etiqueta}:
 *   get:
 *     summary: Obtiene los hechos asociados a una etiqueta
 *     tags: [Hechos]
 *     parameters:
 *       - in: path
 *         name: id_etiqueta
 *         required: true
 *         description: ID de la etiqueta
 *         schema:
 *           type: integer
 *           example: 1
 *     responses:
 *       200:
 *         description: Lista de hechos con esa etiqueta
 *       404:
 *         description: No se encontraron hechos
 *       500:
 *         description: Error del servidor
 */
router.get('/etiqueta/:id_etiqueta', async (req, res) => {
    try {
        const id = parseInt(req.params.id_etiqueta);
        const hechos = await HechosService.getHechosPorEtiqueta(id);

        if (hechos.length === 0) {
            return res.status(404).json({ error: 'No se encontraron hechos con esa etiqueta' });
        }

        const hechosDTO = hechos.map(h => new HechoDTO(h));
        res.json(hechosDTO);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

/**
 * @swagger
 * /api/hechos:
 *   post:
 *     summary: Crea un nuevo hecho histórico (solo admin)
 *     tags: [Hechos]
 *     security:
 *       - BearerAuth: []
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               titulo:
 *                 type: string
 *               descripcion:
 *                 type: string
 *               fecha_evento:
 *                 type: string
 *                 format: date
 *               seccion_id:
 *                 type: integer
 *               imagen_url:
 *                 type: string
 *               video_url:
 *                 type: string
 *               coordenadas_3d:
 *                 type: string
 *     responses:
 *       200:
 *         description: Hecho creado exitosamente
 *       403:
 *         description: No autorizado
 *       500:
 *         description: Error interno
 */
router.post('/', authenticateToken, async (req, res) => {
    try {
        const usuario = req.user;

        if (usuario.rol !== 1) {
            return res.status(403).json({ error: 'Acceso denegado: solo administradores pueden agregar hechos' });
        }

        const result = await HechosService.crearHecho(req.body);
        res.json(result);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

/**
 * @swagger
 * /api/hechos/{id}:
 *   delete:
 *     summary: Elimina un hecho histórico (solo admin)
 *     tags: [Hechos]
 *     security:
 *       - BearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         description: ID del hecho a eliminar
 *         schema:
 *           type: integer
 *     responses:
 *       200:
 *         description: Hecho eliminado correctamente
 *       403:
 *         description: Acceso denegado (no admin)
 *       404:
 *         description: Hecho no encontrado
 *       500:
 *         description: Error del servidor
 */
router.delete('/:id', authenticateToken, async (req, res) => {
    try {
        const usuario = req.user;
        if (usuario.rol !== 1) {
            return res.status(403).json({ error: 'Acceso denegado: solo administradores pueden eliminar hechos' });
        }

        const id_hecho = parseInt(req.params.id);
        const result = await HechosService.eliminarHecho(id_hecho);
        res.json(result);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

/**
 * @swagger
 * /api/hechos/{id}:
 *   get:
 *     summary: Obtiene un hecho histórico por ID
 *     tags: [Hechos]
 *     security:
 *       - BearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: integer
 *     responses:
 *       200:
 *         description: Hecho obtenido
 *       404:
 *         description: No encontrado
 */
router.get('/:id', authenticateToken, async (req, res) => {
    try {
        const hecho = await HechosService.getHechoById(req.params.id);
        if (!hecho) return res.status(404).json({ error: 'Hecho no encontrado' });

        const hechoDTO = new HechoDTO(hecho);
        res.json(hechoDTO);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

module.exports = router;