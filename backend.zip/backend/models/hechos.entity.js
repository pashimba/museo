// models/film.entity.js
class HechosHistoricos{
    constructor({ id_hecho, titulo, descripcion, fecha_evento, seccion_id, imagen_url, video_url }) {
        this.hecho_id = id_hecho;
        this.title = titulo;
        this.description = descripcion;
        this.evento_fecha = fecha_evento;
        this.id_seccion = seccion_id;
        this.url_imagen = imagen_url;
        this.url_video = video_url;
    }
}

module.exports = HechosHistoricos;