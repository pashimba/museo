class HechosHistoricosDTO {
    constructor(hecho) {
        this.id = hecho.id_hecho;
        this.title = hecho.titulo;
        this.description = hecho.descripcion;
        this.eventYear = hecho.fecha_evento;
        this.sectionId = hecho.seccion_id;
        this.image = hecho.imagen_url;
        this.video = hecho.video_url;
        this.coordinates3D = hecho.coordenadas_3d;
    }
}

module.exports = HechosHistoricosDTO;