module.exports = {
    testEnvironment: 'node',
};