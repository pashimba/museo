const express = require('express');
const cors = require('cors');
const hechoRoutes = require('./routes/hechos');
const authRoutes = require('./routes/auth');

const app = express();

// Configurar CORS correctamente (permisos para el cors)
app.use(cors({
  origin: 'http://localhost:5173', // Solo permite ese origen
  methods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],
  allowedHeaders: ['Content-Type', 'Authorization'],
  credentials: true // si usas cookies o tokens
}));

// Manejar preflight OPTIONS en todas las rutas
app.options('*', cors());

app.use(express.json());
app.use('/api/hechos', hechoRoutes);
app.use('/api/auth', authRoutes);

app.get('/', (req, res) => {
  res.send('API del Museo funcionando correctamente :)');
});


module.exports = app;