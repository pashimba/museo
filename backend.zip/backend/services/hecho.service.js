const db = require('../db');

class HechoService {
    // Obtener todos los hechos
    static async getAllHechos() {
        try {
            const [rows] = await db.query('SELECT * FROM hechos_historicos');
            return rows;
        } catch (error) {
            throw new Error('Error al obtener los hechos');
        }
    }

    // Obtener un hecho por ID
    static async getHechoById(id) {
        try {
            const [rows] = await db.query('SELECT * FROM hechos_historicos WHERE id_hecho = ?', [id]);
            if (rows.length === 0) return null;
            return rows[0];
        } catch (error) {
            throw new Error('Error al obtener el hecho');
        }
    }

    static async getHechosOrdenadosPorFecha() {
    try {
        const [rows] = await db.query('SELECT * FROM hechos_historicos ORDER BY fecha_evento ASC');
        return rows;
    } catch (error) {
        throw new Error('Error al obtener hechos históricos ordenados por fecha');
    }
}

static async getHechosPorSeccion(id_seccion) {
    try {
        const [rows] = await db.query(
            'SELECT * FROM hechos_historicos WHERE seccion_id = ?',
            [id_seccion]
        );
        return rows;
    } catch (error) {
        throw new Error('Error al obtener hechos por sección');
    }
}

static async getHechosPorEtiqueta(id_etiqueta) {
    try {
        const [rows] = await db.query(
            `SELECT h.*
             FROM hechos_historicos h
             JOIN hecho_etiqueta he ON h.id_hecho = he.id_hecho
             WHERE he.id_etiqueta = ?`,
            [id_etiqueta]
        );
        return rows;
    } catch (error) {
        throw new Error('Error al obtener hechos por etiqueta');
    }
}

static async crearHecho(data) {
    try {
        const {
            titulo,
            descripcion,
            fecha_evento,
            seccion_id,
            imagen_url,
            video_url,
            coordenadas_3d
        } = data;

        await db.query(
            `INSERT INTO hechos_historicos 
            (titulo, descripcion, fecha_evento, seccion_id, imagen_url, video_url, coordenadas_3d) 
            VALUES (?, ?, ?, ?, ?, ?, ?)`,
            [titulo, descripcion, fecha_evento, seccion_id, imagen_url, video_url, coordenadas_3d]
        );

        return { message: 'Hecho histórico creado correctamente' };
    } catch (error) {
        throw new Error('Error al crear el hecho histórico');
    }
}

static async eliminarHecho(id_hecho) {
    try {
        const [result] = await db.query('DELETE FROM hechos_historicos WHERE id_hecho = ?', [id_hecho]);
        if (result.affectedRows === 0) {
            throw new Error('Hecho no encontrado');
        }
        return { message: 'Hecho eliminado correctamente' };
    } catch (error) {
        throw new Error('Error al eliminar el hecho');
    }
}

}

module.exports = HechoService;